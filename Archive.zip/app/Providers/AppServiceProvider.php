<?php
namespace App\Providers;

use App\Models\Campaign;
use App\Models\Lead;
use App\Policies\CampaignPolicy;
use App\Policies\LeadPolicy;
use App\Services\Discovery\DiscoveryManager;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        $this->app->singleton(DiscoveryManager::class, fn () => new DiscoveryManager());
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Paginator::useBootstrapFive();
        DiscoveryManager::boot();
        Gate::policy(Lead::class, LeadPolicy::class);
        Gate::policy(Campaign::class, CampaignPolicy::class);
    }
}
