<?php

use App\Http\Controllers\AiUsageController;
use App\Http\Controllers\AuditLogController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CampaignController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\EmailController;
use App\Http\Controllers\FollowUpController;
use App\Http\Controllers\FreelancerAccountController;
use App\Http\Controllers\FreelancerBidController;
use App\Http\Controllers\FreelancerSettingsController;
use App\Http\Controllers\LeadController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\OpportunityController;
use App\Http\Controllers\PipelineController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\SettingsController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Guest / Auth Routes
|--------------------------------------------------------------------------
*/
Route::middleware('guest')->group(function () {
    Route::get('login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('login', [AuthController::class, 'login']);
    Route::get('register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('register', [AuthController::class, 'register']);
    Route::get('forgot-password', [AuthController::class, 'showForgot'])->name('password.request');
    Route::post('forgot-password', [AuthController::class, 'sendResetLink'])->name('password.email');
});

Route::post('logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

Route::get('/', function () {
    return Auth::check()
        ? redirect()->route('dashboard')
        : view('welcome');
});

/*
|--------------------------------------------------------------------------
| Authenticated Routes
|--------------------------------------------------------------------------
*/
Route::middleware('auth')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // Profile & notifications
    Route::get('profile', [ProfileController::class, 'index'])->name('profile.index');
    Route::patch('profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::post('notifications/read-all', [NotificationController::class, 'markAllRead'])->name('notifications.read-all');

    // Campaigns (Find Projects)
    Route::get('campaigns', [CampaignController::class, 'index'])->name('campaigns.index');
    Route::get('campaigns/create', [CampaignController::class, 'showCreate'])->name('campaigns.create');
    Route::post('campaigns', [CampaignController::class, 'store'])->name('campaigns.store');
    Route::get('campaigns/{campaign}', [CampaignController::class, 'show'])->name('campaigns.show');
    Route::get('campaigns/{campaign}/progress', [CampaignController::class, 'progress'])->name('campaigns.progress');
    Route::delete('campaigns/{campaign}/leads', [CampaignController::class, 'destroyLeads'])->name('campaigns.leads.destroy');
    Route::post('campaigns/{campaign}/regenerate', [CampaignController::class, 'regenerate'])->name('campaigns.regenerate');
    Route::post('campaigns/{campaign}/pause', [CampaignController::class, 'pause'])->name('campaigns.pause');
    Route::post('campaigns/{campaign}/resume', [CampaignController::class, 'resume'])->name('campaigns.resume');
    Route::post('campaigns/{campaign}/cancel', [CampaignController::class, 'cancel'])->name('campaigns.cancel');

    // Leads
    Route::get('leads', [LeadController::class, 'index'])->name('leads.index');
    Route::get('leads/create', [LeadController::class, 'create'])->name('leads.create');
    Route::post('leads', [LeadController::class, 'store'])->name('leads.store');
    Route::get('leads/import', [LeadController::class, 'importView'])->name('leads.import');
    Route::post('leads/import', [LeadController::class, 'import'])->name('leads.import.submit');
    Route::post('leads/{lead}/bulk-status', [LeadController::class, 'bulkStatus'])->name('leads.bulk-status');
    Route::get('leads/{lead}/edit', [LeadController::class, 'edit'])->name('leads.edit');
    Route::patch('leads/{lead}', [LeadController::class, 'update'])->name('leads.update');
    Route::get('leads/{lead}', [LeadController::class, 'show'])->name('leads.show');
    Route::delete('leads/{lead}', [LeadController::class, 'destroy'])->name('leads.destroy');
    Route::post('leads/{lead}/status', [LeadController::class, 'updateStatus'])->name('leads.update-status');
    Route::post('leads/{lead}/analyse', [LeadController::class, 'analyse'])->name('leads.analyse');
    Route::post('leads/{lead}/claim', [LeadController::class, 'claim'])->name('leads.claim');
    Route::post('leads/{lead}/notes', [LeadController::class, 'addNote'])->name('leads.add-note');
    Route::post('leads/{lead}/quotation', [EmailController::class, 'generateQuotation'])->name('quotations.generate');

    // Pipeline (kanban)
    Route::get('pipeline', [PipelineController::class, 'index'])->name('pipeline.index');
    Route::post('pipeline/{lead}/move', [PipelineController::class, 'move'])->name('pipeline.move');

    // Opportunities
    Route::get('opportunities', [OpportunityController::class, 'index'])->name('opportunities.index');
    Route::get('opportunities/{lead}', [OpportunityController::class, 'show'])->name('opportunities.show');

    // Email outreach
    Route::get('emails', [EmailController::class, 'index'])->name('emails.index');
    Route::get('emails/pending', [EmailController::class, 'pending'])->name('emails.pending');
    Route::post('emails/{lead}/generate', [EmailController::class, 'generate'])->name('emails.generate');
    Route::patch('emails/{email}', [EmailController::class, 'updateDraft'])->name('emails.update');
    Route::delete('emails/{email}', [EmailController::class, 'destroyDraft'])->name('emails.destroy');
    Route::post('emails/{email}/approve', [EmailController::class, 'approve'])->name('emails.approve');
    Route::post('emails/{email}/send', [EmailController::class, 'send'])->name('emails.send');

    // Follow-ups
    Route::get('followups', [FollowUpController::class, 'index'])->name('followups.index');
    Route::post('followups/{followUp}/complete', [FollowUpController::class, 'complete'])->name('followups.complete');
    Route::post('followups/trigger/{lead}', [FollowUpController::class, 'trigger'])->name('followups.trigger');

    // Reports
    Route::get('reports', [ReportController::class, 'index'])->name('reports.index');

    // Freelancer.com auto-bidding
    Route::get('freelancer/dashboard', [FreelancerBidController::class, 'dashboard'])->name('freelancer.dashboard');
    Route::get('freelancer/bids', [FreelancerBidController::class, 'index'])->name('freelancer.bids.index');
    Route::post('freelancer/bids/{bid}/approve', [FreelancerBidController::class, 'approve'])->name('freelancer.bids.approve');
    Route::post('freelancer/bids/{bid}/reject', [FreelancerBidController::class, 'reject'])->name('freelancer.bids.reject');
    Route::get('freelancer/accounts', [FreelancerAccountController::class, 'index'])->name('freelancer.accounts.index')->middleware('role:admin');
    Route::get('freelancer/accounts/create', [FreelancerAccountController::class, 'create'])->name('freelancer.accounts.create')->middleware('role:admin');
    Route::post('freelancer/accounts', [FreelancerAccountController::class, 'store'])->name('freelancer.accounts.store')->middleware('role:admin');
    Route::get('freelancer/accounts/{account}/edit', [FreelancerAccountController::class, 'edit'])->name('freelancer.accounts.edit')->middleware('role:admin');
    Route::patch('freelancer/accounts/{account}', [FreelancerAccountController::class, 'update'])->name('freelancer.accounts.update')->middleware('role:admin');
    Route::delete('freelancer/accounts/{account}', [FreelancerAccountController::class, 'destroy'])->name('freelancer.accounts.destroy')->middleware('role:admin');
    Route::post('freelancer/accounts/{account}/test', [FreelancerAccountController::class, 'testConnection'])->name('freelancer.accounts.test')->middleware('role:admin');
    Route::post('freelancer/accounts/{account}/scan', [FreelancerAccountController::class, 'scanNow'])->name('freelancer.accounts.scan')->middleware('role:admin');
    Route::get('freelancer/settings', [FreelancerSettingsController::class, 'index'])->name('freelancer.settings.index')->middleware('role:admin');
    Route::post('freelancer/settings', [FreelancerSettingsController::class, 'update'])->name('freelancer.settings.update')->middleware('role:admin');

    // AI Usage
    Route::get('ai/usage', [AiUsageController::class, 'index'])->name('ai.usage');

    // Services & Settings (admin)
    Route::get('services', [ServiceController::class, 'index'])->name('services.index');
    Route::get('services/create', [ServiceController::class, 'create'])->name('services.create');
    Route::post('services', [ServiceController::class, 'store'])->name('services.store');
    Route::get('services/{service}', [ServiceController::class, 'show'])->name('services.show');
    Route::post('services/{service}/rules', [ServiceController::class, 'storeRule'])->name('services.rules.store')->middleware('role:admin');
    Route::delete('services/{service}/rules/{rule}', [ServiceController::class, 'deleteRule'])->name('services.rules.destroy')->middleware('role:admin');

    Route::get('audit-logs', [AuditLogController::class, 'index'])->name('audit.index')->middleware('role:admin');
    Route::get('settings', [SettingsController::class, 'index'])->name('settings.index')->middleware('role:admin');
    Route::post('settings', [SettingsController::class, 'update'])->name('settings.update')->middleware('role:admin');
});