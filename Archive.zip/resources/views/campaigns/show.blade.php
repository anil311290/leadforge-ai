@extends('layouts.app')
@section('title', $campaign->name)

@section('content')
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
    <div>
        <a href="{{ route('campaigns.index') }}" class="small text-muted">&larr; Campaigns</a>
        <h4 class="fw-bold mb-0">{{ $campaign->name }}</h4>
        <p class="text-muted small mb-0"><i class="bi bi-geo-alt me-1"></i>{{ $campaign->location }} @if($campaign->radius_km)· {{ $campaign->radius_km }} km @endif</p>
    </div>
    <div class="d-flex gap-2">
        <form method="POST" action="{{ route('campaigns.regenerate', $campaign) }}" id="regenerateLeadsForm">
            @csrf
            <button type="button" class="btn btn-primary btn-sm" data-confirm-target="regenerateLeadsForm" data-confirm-title="Regenerate leads?" data-confirm-message="This will delete existing leads from this campaign and generate fresh leads using the same campaign settings." data-confirm-button="Regenerate Leads" data-confirm-style="btn-primary"><i class="bi bi-arrow-clockwise me-1"></i>Regenerate Leads</button>
        </form>
        <form method="POST" action="{{ route('campaigns.leads.destroy', $campaign) }}" id="deleteExistingLeadsForm">
            @csrf
            @method('DELETE')
            <button type="button" class="btn btn-outline-danger btn-sm" data-confirm-target="deleteExistingLeadsForm" data-confirm-title="Delete existing leads?" data-confirm-message="This will remove all existing leads from this campaign. The campaign itself will remain available." data-confirm-button="Delete Leads" data-confirm-style="btn-danger"><i class="bi bi-trash me-1"></i>Delete Existing</button>
        </form>
        @if($campaign->status === 'running')
            <form method="POST" action="{{ route('campaigns.pause', $campaign) }}">@csrf<button class="btn btn-outline-warning btn-sm"><i class="bi bi-pause me-1"></i>Pause</button></form>
        @elseif($campaign->status === 'paused')
            <form method="POST" action="{{ route('campaigns.resume', $campaign) }}">@csrf<button class="btn btn-success btn-sm"><i class="bi bi-play me-1"></i>Resume</button></form>
        @endif
        @if(in_array($campaign->status, ['running','paused']))
            <form method="POST" action="{{ route('campaigns.cancel', $campaign) }}">@csrf<button class="btn btn-outline-danger btn-sm"><i class="bi bi-x-lg me-1"></i>Cancel</button></form>
        @endif
    </div>
</div>

@if($campaign->error)
<div class="alert alert-danger"><i class="bi bi-exclamation-triangle me-2"></i>{{ $campaign->error }}</div>
@endif

{{-- Live progress tracker --}}
<div class="card shadow-sm border-0 mb-4" id="progressCard" data-campaign-id="{{ $campaign->id }}" data-initial-status="{{ $campaign->status }}">
    <div class="card-body p-4">
        <div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
            <h6 class="fw-bold mb-0 d-flex align-items-center gap-2">
                <span id="progressIcon"><i class="bi bi-arrow-repeat text-primary"></i></span>
                <span id="progressStatus">Campaign progress</span>
            </h6>
            <span class="badge rounded-pill fs-6 px-3 py-1" id="progressPercent">{{ $campaign->progress ?? 0 }}%</span>
        </div>

        <div class="progress mb-3" style="height:12px;">
            <div class="progress-bar progress-bar-striped progress-bar-animated" id="progressBar"
                 role="progressbar" style="width:{{ $campaign->progress ?? 0 }}%"></div>
        </div>

        <p class="text-muted small mb-4 d-flex align-items-center gap-2">
            <i class="bi bi-gear text-secondary"></i>
            <span id="progressMessage">{{ $campaign->progress_message ?? 'Waiting to start…' }}</span>
        </p>

        {{-- Pipeline stages --}}
        <div class="row g-2 text-center mb-3" id="stagesRow">
            <div class="col-3">
                <div class="d-flex flex-column align-items-center gap-1">
                    <div class="stage-dot d-flex align-items-center justify-content-center" id="stage-discover"><i class="bi bi-building"></i></div>
                    <span class="small fw-medium">Discover</span>
                </div>
            </div>
            <div class="col-3">
                <div class="d-flex flex-column align-items-center gap-1">
                    <div class="stage-dot d-flex align-items-center justify-content-center" id="stage-scan"><i class="bi bi-search"></i></div>
                    <span class="small fw-medium">Scan</span>
                </div>
            </div>
            <div class="col-3">
                <div class="d-flex flex-column align-items-center gap-1">
                    <div class="stage-dot d-flex align-items-center justify-content-center" id="stage-analyse"><i class="bi bi-motherboard"></i></div>
                    <span class="small fw-medium">Analyse</span>
                </div>
            </div>
            <div class="col-3">
                <div class="d-flex flex-column align-items-center gap-1">
                    <div class="stage-dot d-flex align-items-center justify-content-center" id="stage-done"><i class="bi bi-check-lg"></i></div>
                    <span class="small fw-medium">Complete</span>
                </div>
            </div>
        </div>

        {{-- Live numbers --}}
        <div class="row g-2">
            <div class="col-4">
                <div class="bg-light rounded-3 p-2 text-center">
                    <div class="fw-bold" id="liveTotal">{{ $stats['businesses_discovered'] }}</div>
                    <div class="text-muted small">Discovered</div>
                </div>
            </div>
            <div class="col-4">
                <div class="bg-light rounded-3 p-2 text-center">
                    <div class="fw-bold" id="liveScanned">{{ $stats['websites_scanned'] }}</div>
                    <div class="text-muted small">Scanned</div>
                </div>
            </div>
            <div class="col-4">
                <div class="bg-light rounded-3 p-2 text-center">
                    <div class="fw-bold" id="liveAnalysed">{{ $stats['analysed'] }}</div>
                    <div class="text-muted small">Analysed</div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    {{-- Process Timeline --}}
    <div class="col-12">
        <div class="card shadow-sm border-0">
            <div class="card-body p-4">
                <h6 class="fw-bold mb-3 d-flex align-items-center gap-2">
                    <i class="bi bi-diagram-3 text-primary"></i> Process Timeline
                    <span class="badge bg-light text-muted border fw-normal ms-1 small" id="timelineCount">0 steps</span>
                </h6>
                <div id="timelineContainer">
                    <div class="text-center text-muted small py-3" id="timelineEmpty">
                        <i class="bi bi-hourglass-split me-1"></i> Waiting for process to start…
                    </div>
                    <div class="timeline d-none" id="timelineList"></div>
                </div>
            </div>
        </div>
    </div>

    {{-- Stat tiles --}}
    @php
        $tiles = [
            ['Businesses discovered', $stats['businesses_discovered'], 'bi-building', 'primary'],
            ['Websites found', $stats['websites_found'], 'bi-globe', 'info'],
            ['Websites scanned', $stats['websites_scanned'], 'bi-search', 'secondary'],
            ['Analysed', $stats['analysed'], 'bi-motherboard', 'warning'],
            ['Hot & High', $stats['hot'], 'bi-fire', 'danger'],
            ['Pipeline value', '₹'.number_format($stats['pipeline']), 'bi-cash-stack', 'success'],
        ];
    @endphp
    @foreach($tiles as $t)
    <div class="col-6 col-md-4 col-xl-2">
        <div class="card p-3 shadow-sm text-center">
            <div class="stat-icon mx-auto bg-{{ $t[3] }} bg-opacity-10 text-{{ $t[3] }} mb-2"><i class="bi {{ $t[2] }}"></i></div>
            <div class="fw-bold">{{ $t[1] }}</div>
            <div class="text-muted small">{{ $t[0] }}</div>
        </div>
    </div>
    @endforeach
</div>

<div class="card shadow-sm">
    <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
        <span><i class="bi bi-people me-1 text-primary"></i>Leads in this campaign</span>
        <span class="badge bg-light text-muted border">{{ $leads->total() }}</span>
    </div>
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead><tr><th>Company</th><th>Industry</th><th>Service</th><th>Score</th><th>Est. Value</th><th>Status</th></tr></thead>
            <tbody>
            @forelse($leads as $lead)
                <tr>
                    <td><a href="{{ route('leads.show', $lead) }}">{{ $lead->company }}</a>@if($lead->location)<div class="small text-muted">{{ $lead->location }}</div>@endif</td>
                    <td class="small">{{ $lead->industry ?? '—' }}</td>
                    <td class="small">{{ $lead->recommended_service ?? '—' }}</td>
                    <td>@if($lead->opportunity_score)<span class="badge {{ $lead->score_class ? 'badge-'.strtolower($lead->score_class) : 'badge-ignore' }}">{{ $lead->opportunity_score }}</span>@else<span class="badge bg-light text-muted border">—</span>@endif</td>
                    <td class="small">{{ $lead->estimated_max ? '₹'.number_format($lead->estimated_max) : '—' }}</td>
                    <td><span class="badge bg-light text-dark border">{{ $lead->status }}</span></td>
                </tr>
            @empty
                <tr><td colspan="6" class="text-center text-muted py-4">No leads yet — discovery is still in progress.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    @if($leads->hasPages())
        <div class="card-footer border-top-0 py-3">
            <nav aria-label="Leads pagination">
                <ul class="pagination pagination-sm justify-content-center mb-0 gap-1">
                    {{-- Previous --}}
                    @if ($leads->onFirstPage())
                        <li class="page-item disabled">
                            <span class="page-link border rounded px-3 py-1 small text-muted bg-light"><i class="bi bi-chevron-left"></i> Previous</span>
                        </li>
                    @else
                        <li class="page-item">
                            <a class="page-link border rounded px-3 py-1 small text-dark bg-white" href="{{ $leads->previousPageUrl() }}" rel="prev"><i class="bi bi-chevron-left"></i> Previous</a>
                        </li>
                    @endif

                    {{-- Page numbers --}}
                    @foreach ($leads->getUrlRange(max(1, $leads->currentPage() - 2), min($leads->lastPage(), $leads->currentPage() + 2)) as $page => $url)
                        <li class="page-item {{ $page === $leads->currentPage() ? 'active' : '' }}">
                            <a class="page-link border rounded px-3 py-1 small {{ $page === $leads->currentPage() ? 'bg-primary text-white border-primary' : 'bg-white text-dark' }}" href="{{ $url }}">{{ $page }}</a>
                        </li>
                    @endforeach

                    {{-- Next --}}
                    @if ($leads->hasMorePages())
                        <li class="page-item">
                            <a class="page-link border rounded px-3 py-1 small text-dark bg-white" href="{{ $leads->nextPageUrl() }}" rel="next">Next <i class="bi bi-chevron-right"></i></a>
                        </li>
                    @else
                        <li class="page-item disabled">
                            <span class="page-link border rounded px-3 py-1 small text-muted bg-light">Next <i class="bi bi-chevron-right"></i></span>
                        </li>
                    @endif
                </ul>
            </nav>
        </div>
    @endif
</div>

<div class="modal fade" id="campaignConfirmModal" tabindex="-1" aria-labelledby="campaignConfirmTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header border-0 pb-0">
                <div>
                    <h5 class="modal-title fw-bold" id="campaignConfirmTitle">Confirm action</h5>
                    <p class="text-muted small mb-0">Please review before continuing.</p>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body py-4">
                <div class="d-flex gap-3">
                    <div class="stat-icon bg-warning bg-opacity-10 text-warning flex-shrink-0"><i class="bi bi-exclamation-triangle"></i></div>
                    <p class="mb-0 text-muted" id="campaignConfirmMessage">Are you sure you want to continue?</p>
                </div>
            </div>
            <div class="modal-footer border-0 pt-0">
                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="campaignConfirmButton">Continue</button>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<style>
    .stage-dot{width:44px;height:44px;border-radius:50%;background:#eef1f6;color:#a3adbf;font-size:1.1rem;transition:all .3s}
    .stage-dot.active{background:#1e6fd9;color:#fff;box-shadow:0 0 0 4px rgba(30,111,217,.15)}
    .stage-dot.done{background:#10b981;color:#fff}
    #progressBar{transition:width .6s ease}
    .timeline{max-height:300px;overflow-y:auto}
</style>
<script>
document.querySelectorAll('[data-confirm-target]').forEach(button => {
    button.addEventListener('click', () => {
        const modalEl = document.getElementById('campaignConfirmModal');
        const title = document.getElementById('campaignConfirmTitle');
        const message = document.getElementById('campaignConfirmMessage');
        const confirmButton = document.getElementById('campaignConfirmButton');
        const formId = button.dataset.confirmTarget;

        title.textContent = button.dataset.confirmTitle || 'Confirm action';
        message.textContent = button.dataset.confirmMessage || 'Are you sure you want to continue?';
        confirmButton.textContent = button.dataset.confirmButton || 'Continue';
        confirmButton.className = 'btn ' + (button.dataset.confirmStyle || 'btn-primary');
        confirmButton.dataset.formId = formId;

        bootstrap.Modal.getOrCreateInstance(modalEl).show();
    });
});

document.getElementById('campaignConfirmButton')?.addEventListener('click', function() {
    const form = document.getElementById(this.dataset.formId);
    if (form) {
        this.disabled = true;
        form.submit();
    }
});

(function(){
    const card = document.getElementById('progressCard');
    if (!card) return;
    const campaignId = card.dataset.campaignId;
    const url = "{{ route('campaigns.progress', $campaign) }}";

    const bar = document.getElementById('progressBar');
    const pct = document.getElementById('progressPercent');
    const msg = document.getElementById('progressMessage');
    const statusEl = document.getElementById('progressStatus');
    const iconEl = document.getElementById('progressIcon');
    const liveTotal = document.getElementById('liveTotal');
    const liveScanned = document.getElementById('liveScanned');
    const liveAnalysed = document.getElementById('liveAnalysed');

    function setStage(name, state){
        const el = document.getElementById('stage-' + name);
        if (!el) return;
        el.classList.remove('active','done');
        if (state) el.classList.add(state);
    }

    // Timeline
    const timelineList = document.getElementById('timelineList');
    const timelineEmpty = document.getElementById('timelineEmpty');
    const timelineCount = document.getElementById('timelineCount');
    const seenTimeline = new Set();

    function renderTimeline(entries){
        if (!entries || !entries.length) return;

        timelineEmpty?.classList.add('d-none');
        timelineList?.classList.remove('d-none');

        let newItems = 0;
        entries.forEach(entry => {
            const key = entry.type + '_' + entry.created_at;
            if (seenTimeline.has(key)) return;
            seenTimeline.add(key);
            newItems++;

            const icons = {
                'campaign_running': 'bi-play-circle text-primary',
                'campaign_completed': 'bi-check-circle-fill text-success',
                'campaign_failed': 'bi-x-circle-fill text-danger',
                'lead_discovered': 'bi-building text-info',
                'analysis_completed': 'bi-motherboard text-warning',
                'email_generated': 'bi-envelope-paper text-primary',
                'email_sent': 'bi-send-check text-success',
                'reply_received': 'bi-reply-all text-info',
                'follow_up_due': 'bi-alarm text-warning',
                'status_changed': 'bi-arrow-left-right text-secondary',
            };
            const icon = icons[entry.type] || 'bi-record-circle text-muted';

            const div = document.createElement('div');
            div.className = 'd-flex align-items-start gap-3 py-2 border-bottom';
            div.innerHTML = `
                <div class="mt-1"><i class="bi ${icon} fs-6"></i></div>
                <div class="flex-grow-1">
                    <div class="fw-medium small">${entry.title || entry.type.replace(/_/g, ' ')}</div>
                    <div class="text-muted small"><i class="bi bi-clock me-1"></i>${entry.time}</div>
                </div>
            `;
            timelineList?.prepend(div);
        });

        if (newItems > 0 && timelineCount) {
            timelineCount.textContent = seenTimeline.size + ' steps';
        }
    }

    function update(data){
        // Timeline
        if (data.timeline) renderTimeline(data.timeline);

        bar.style.width = data.progress + '%';
        pct.textContent = data.progress + '%';

        if (data.message) msg.textContent = data.message;

        const status = data.status;
        let label = 'Campaign progress';
        let icon = '<i class="bi bi-arrow-repeat text-primary"></i>';
        let barClass = 'bg-primary';

        if (status === 'running') {
            label = 'Running…';
            icon = '<i class="bi bi-arrow-repeat text-primary"></i>';
            barClass = 'bg-primary';
        } else if (status === 'paused') {
            label = 'Paused';
            icon = '<i class="bi bi-pause-circle text-warning"></i>';
            barClass = 'bg-warning';
        } else if (status === 'completed') {
            label = 'Completed';
            icon = '<i class="bi bi-check-circle-fill text-success"></i>';
            barClass = 'bg-success';
        } else if (status === 'failed') {
            label = 'Failed';
            icon = '<i class="bi bi-x-circle-fill text-danger"></i>';
            barClass = 'bg-danger';
        }

        statusEl.textContent = label;
        iconEl.innerHTML = icon;
        bar.className = 'progress-bar progress-bar-striped progress-bar-animated ' + barClass;

        // Stages
        const p = data.progress;
        setStage('discover', p > 5 ? 'done' : (p > 0 ? 'active' : null));
        setStage('scan', p >= 55 ? (p > 80 ? 'done' : 'active') : null);
        setStage('analyse', p >= 80 ? (p >= 100 ? 'done' : 'active') : null);
        setStage('done', p >= 100 ? 'done' : null);

        // Live numbers
        if (data.leads) {
            liveTotal.textContent = data.leads.total;
            liveScanned.textContent = data.leads.scanned;
            liveAnalysed.textContent = data.leads.analysed;
        }

        // Stop polling once finished — do NOT reload the page
        if (['completed','failed','cancelled'].includes(status)) {
            clearInterval(timer);
        }
    }

    async function poll(){
        try {
            const res = await fetch(url, { headers: { 'Accept': 'application/json' } });
            const data = await res.json();
            update(data);
        } catch (e) {
            // ignore transient errors
        }
    }

    let timer = null;
    const initialStatus = card.dataset.initialStatus;
    if (['running','paused'].includes(initialStatus)) {
        timer = setInterval(poll, 2000);
    } else {
        // Still render final state once
        poll();
    }
})();
</script>
@endsection